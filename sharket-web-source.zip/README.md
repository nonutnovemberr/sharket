# 🦈 Sharket Plugin Web Store

Official Web Store for **Sharket Plugin** Minecraft systems: **SharketCrates**, **SharketAuctions**, **SussyBaka**, and **Vulcan Anti-Cheat**.

Built with **Next.js 16**, **Tailwind CSS**, and **TypeScript**, designed with a modern Minecraft Aquatic Light UI theme.

---

## 🌟 Produk Sharket Plugin

1. **SharketCrates**: DonutSMP style custom crate system dengan in-game GUI editor (`/sc gui`), pilihan 1 dari 7 reward, KeyAll global event otomatis, dan hologram interaktif.
2. **SharketAuctions**: Auction House modern dengan Anti-Dupe 100%, Sign GUI Search, Category Filters, dan performa tinggi async (0.00% tick delay).
3. **SussyBaka**: Tool pengawasan pemain senyap in-game, integrasi multi-anticheat, investigasi real-time, dan log riwayat audit.
4. **Vulcan Anti Cheat**: Konfigurasi dan optimasi deteksi cheat Minecraft terlengkap dengan Judgement Day (`/jday`) dan Discord webhook integration.

---

## 🚀 Deployment (Vercel)

Website ini siap di-deploy langsung ke [Vercel](https://vercel.com):
- Framework Preset: **Next.js**
- Build Command: `next build`
- Output Directory: `.next`

---

## 💻 Local Development

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build
```

---

## ⚙️ Kustomisasi Nomor WhatsApp Admin

Buka file [`src/components/OrderModal.tsx`](src/components/OrderModal.tsx):
Ganti nilai default `adminPhone`:
```tsx
const [adminPhone, setAdminPhone] = useState('6281234567890'); // Ganti dengan nomor WhatsApp Anda
```
