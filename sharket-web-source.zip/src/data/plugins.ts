export interface PluginItem {
  id: string;
  name: string;
  subtitle: string;
  tag: string;
  tagColor: 'red' | 'yellow' | 'cyan' | 'orange';
  price: string;
  originalPrice: string;
  salesCount: number;
  version: string;
  category: 'Economy' | 'Security' | 'Gameplay';
  description: string;
  longDescription: string;
  colorScheme: {
    primary: string;
    secondary: string;
    gradient: string;
  };
  features: string[];
  specs: {
    label: string;
    value: string;
  }[];
  commands: {
    cmd: string;
    desc: string;
    perm: string;
  }[];
  placeholders?: {
    placeholder: string;
    desc: string;
  }[];
  whatsappMessage: string;
}

export const PLUGINS_DATA: PluginItem[] = [
  {
    id: 'sharket-auctions',
    name: 'SharketAuctions',
    subtitle: 'Sistem auction house lengkap dengan fitur browse, buy, sell, dan admin tools',
    tag: 'POPULAR',
    tagColor: 'cyan',
    price: 'Rp 39.999',
    originalPrice: 'Rp 60.000',
    salesCount: 17,
    version: '1.21 - 26.x',
    category: 'Economy',
    description: 'Sistem auction house lengkap dengan fitur browse, buy, sell, dan admin tools. Termasuk quick buy/sell donutsmp style.',
    longDescription: 'Dilengkapi fitur lengkap browse, buy, sell, admin tools, dan sistem quick buy/sell ala donutsmp style. Highly customizable dengan opsi konfigurasi yang sangat fleksibel untuk server Minecraft Anda.',
    colorScheme: {
      primary: '#38BDF8',
      secondary: '#FDE047',
      gradient: 'from-sky-400 via-teal-300 to-amber-200',
    },
    features: [
      'Sistem auction house lengkap dengan fitur browse, buy, sell, dan admin tools',
      'Donutsmp style quick buy/sell system',
      'Sistem validasi transaksi berlapis untuk mencegah duplikasi item',
      'Fitur pratinjau isi Shulker Box secara langsung di dalam GUI',
      'Highly customizable: layout menu GUI, pesan pesan, item ikon, dan suara',
      'Penyimpanan asynchronous berkecepatan tinggi dengan HikariCP (MySQL & SQLite)',
      'PlaceholderAPI support resmi dengan prefix %sharket_...%',
      'Sistem proteksi lisensi resmi (file .jar dan lisensi diberikan oleh Admin setelah pembayaran)',
    ],
    specs: [
      { label: 'Kompatibilitas Fork', value: 'Paper, Purpur, Leaf, Pufferfish, Folia, Gale (1.21 - 26.x)' },
      { label: 'Dependencies Wajib', value: 'Vault (beserta plugin ekonomi seperti EssentialsX)' },
      { label: 'Dependencies Opsional', value: 'PlaceholderAPI, WorldGuard' },
      { label: 'Database', value: 'SQLite (Lokal) & MySQL / MariaDB' },
      { label: 'Placeholder Prefix', value: '%sharket_<placeholder>%' },
      { label: 'Performa Tick', value: '0.00ms MSPT (Full Asynchronous)' },
      { label: 'Purchased', value: '17 purchased' },
    ],
    commands: [
      { cmd: '/shark ah', desc: 'Membuka menu utama Auction House', perm: 'sharketauctions.use' },
      { cmd: '/shark sell <harga>', desc: 'Menjual item yang sedang dipegang', perm: 'sharketauctions.sell' },
      { cmd: '/shark expired', desc: 'Membuka menu item lelang kedaluwarsa', perm: 'sharketauctions.use' },
      { cmd: '/shark reload', desc: 'Memuat ulang konfigurasi plugin', perm: 'sharketauctions.admin' },
      { cmd: '/shark license', desc: 'Memeriksa status lisensi aktif', perm: 'sharketauctions.admin' },
    ],
    placeholders: [
      { placeholder: '%sharket_active_listings%', desc: "Player's active listing count" },
      { placeholder: '%sharket_total_earned%', desc: 'Total money earned from sales' },
      { placeholder: '%sharket_total_spent%', desc: 'Total money spent on purchases' },
      { placeholder: '%sharket_items_bought%', desc: 'Number of items bought' },
      { placeholder: '%sharket_items_sold%', desc: 'Number of items sold' },
    ],
    whatsappMessage: 'halo\nsaya ingin membeli plugin "SharketAuctions"',
  },
  {
    id: 'sharket-crates',
    name: 'SharketCrates',
    subtitle: 'DonutSMP style custom crate system dengan in-game editor, keyall event, dan hologram',
    tag: 'NEW',
    tagColor: 'cyan',
    price: 'Rp 15.000',
    originalPrice: 'Rp 25.000',
    salesCount: 19,
    version: '1.21 - 26.x',
    category: 'Gameplay',
    description: 'Sistem crate eksklusif ala DonutSMP. Dilengkapi pilihan 1 dari 7 reward, in-game GUI editor, KeyAll event otomatis, dukungan hologram interaktif, dan kustomisasi command berdurasi.',
    longDescription: 'SharketCrates menghadirkan pengalaman gacha dan crate eksklusif ala DonutSMP langsung ke server Minecraft Anda. Pemain dapat membuka crate dan memilih 1 dari 7 pilihan reward (Armor, Tools, Spawners, atau Custom Items). Dilengkapi in-game GUI editor (/sc gui) untuk menambah atau mengatur reward tanpa repot coding, sistem KeyAll global otomatis (/sc keyall) yang terjadwal dengan hitung mundur placeholder, serta hologram interaktif (/store & Keys display) di atas crate. Mendukung item khusus dengan perintah kedaluwarsa (self-destruct duration command seperti Amethyst Crate).',
    colorScheme: {
      primary: '#2DD4BF',
      secondary: '#38BDF8',
      gradient: 'from-teal-400 via-cyan-400 to-sky-300',
    },
    features: [
      'DonutSMP Style Reward System: pemain dapat memilih 1 dari 7 pilihan reward unik saat membuka crate',
      'In-Game GUI Editor (/sc gui): kelola isi crate, material blok, dan peluang reward secara interaktif langsung di dalam game',
      'Global KeyAll Event Otomatis: bagikan kunci crate ke seluruh pemain online secara berkala (/sc keyall) dengan timer cooldown',
      'Dukungan Hologram Interaktif: menampilkan status kunci pemain dan teks /store otomatis di atas blok crate',
      'Dukungan Command Rewards & Expiration: integrasi perintah berdurasi (seperti item temporer/self-destruct ala Amethyst Crate)',
      'Ringan & Asynchronous: dioptimalkan untuk performa tinggi tanpa menyebabkan tick lag atau TPS drop',
      'PlaceholderAPI Support: integrasi penuh placeholder waktu KeyAll dan statistik crate server',
      'Proteksi Lisensi Resmi Sharket: sistem lisensi otomatis (license.yml) dengan kode aktivasi resmi dari Admin',
    ],
    specs: [
      { label: 'Kompatibilitas Fork', value: 'Paper, Purpur, Leaf, Pufferfish, Folia, Gale (1.21 - 26.x)' },
      { label: 'Dependencies Wajib', value: 'PlaceholderAPI' },
      { label: 'In-Game Editor', value: 'Full GUI Editor (/sc gui)' },
      { label: 'Sistem Event', value: 'Automated Global KeyAll' },
      { label: 'Placeholder Prefix', value: '%sharketcrates_<placeholder>%' },
      { label: 'Purchased', value: '19 purchased' },
    ],
    commands: [
      { cmd: '/sc gui', desc: 'Membuka menu in-game GUI editor crate', perm: 'sharketcrates.admin' },
      { cmd: '/sc givekey <player> <crate> <amount>', desc: 'Memberikan kunci crate fisik ke pemain', perm: 'sharketcrates.admin' },
      { cmd: '/sc givecrate <player> <crate> <amount>', desc: 'Memberikan blok crate fisik untuk dipasang', perm: 'sharketcrates.admin' },
      { cmd: '/sc keyall <amount> <crate>', desc: 'Membagikan kunci crate ke seluruh pemain online', perm: 'sharketcrates.admin' },
      { cmd: '/sc forcekeyall', desc: 'Memaksa eksekusi KeyAll instan dan mereset timer', perm: 'sharketcrates.admin' },
      { cmd: '/sc reload', desc: 'Memuat ulang konfigurasi config.yml dan messages.yml', perm: 'sharketcrates.admin' },
    ],
    placeholders: [
      { placeholder: '%sharketcrates_keyall%', desc: 'Waktu hitung mundur menuju KeyAll berikutnya' },
      { placeholder: '%sharketcrates_keys_<crate>%', desc: 'Jumlah sisa kunci crate yang dimiliki pemain (contoh: %sharketcrates_keys_common%)' },
    ],
    whatsappMessage: 'halo\nsaya ingin membeli plugin "SharketCrates"',
  },
  {
    id: 'sussy-baka',
    name: 'SussyBaka',
    subtitle: 'Sistem pelacakan dan moderasi anti cheat terpusat untuk staf server',
    tag: 'SECURITY',
    tagColor: 'yellow',
    price: 'Rp 24.999',
    originalPrice: 'Rp 40.000',
    salesCount: 13,
    version: '1.20 - 26.1',
    category: 'Security',
    description: 'Kumpulkan seluruh peringatan anti cheat ke dalam satu menu GUI terpusat. Dilengkapi fitur spectate instan, sortir pemain terflag, dan integrasi multi anti cheat.',
    longDescription: 'SussyBaka merangkum seluruh peringatan anti cheat menjadi satu dashboard GUI terpusat (/sus). Staf dapat langsung memantau pemain terflag, jenis pelanggaran, serta aksi moderasi cepat: klik kiri untuk spectate senyap dan klik kanan untuk clear list. Highly customizable.',
    colorScheme: {
      primary: '#FDE047',
      secondary: '#38BDF8',
      gradient: 'from-amber-200 via-sky-300 to-indigo-300',
    },
    features: [
      'Dashboard GUI terpusat (/sussybaka & /sus): seluruh peringatan anti cheat dirangkum rapi ke dalam tampilan kepala pemain',
      'Aksi moderasi cepat: klik kiri untuk spectate senyap ke target (online/offline), klik kanan untuk clear tracker',
      'Integrasi multi anti cheat: otomatis hook ke GrimAC, Vulcan, Matrix, Polar, Spartan, Themis, dan 10+ anti cheat lainnya',
      'Fitur sortir pemain terflag: opsi sortir Most Flagged dan Recently Flagged',
      'Highly customizable: kustomisasi penuh tata letak GUI, lore, tombol, sound effect, MiniMessage, dan legacy color code',
      'Dirancang hemat resource untuk Paper dan Folia dengan penggunaan server thread hanya 0.01%',
    ],
    specs: [
      { label: 'Kompatibilitas Fork', value: 'Paper, Purpur, Leaf, Pufferfish, Folia, Gale (1.20 - 26.1)' },
      { label: 'Dependencies Wajib', value: 'Tidak ada (Bisa jalan mandiri)' },
      { label: 'Anti Cheat yang Didukung', value: 'Vulcan, GrimAC, Polar, Spartan, Matrix, LPX, Themis, dll.' },
      { label: 'Database', value: 'SQLite & MariaDB / MySQL' },
      { label: 'Penggunaan Memori', value: '< 15MB RAM Overhead' },
      { label: 'Purchased', value: '13 purchased' },
    ],
    commands: [
      { cmd: '/sussybaka (alias /sus)', desc: 'Membuka GUI dashboard pemain yang terflag', perm: 'sussybaka.use' },
      { cmd: '/sussybaka <player>', desc: 'Membuka GUI investigasi detail pemain tertentu', perm: 'sussybaka.use' },
      { cmd: '/sussybaka reload', desc: 'Memuat ulang konfigurasi dan membersihkan cache sesi', perm: 'sussybaka.admin' },
      { cmd: '/sussybaka clear', desc: 'Menghapus seluruh riwayat flag kecurangan dari database', perm: 'sussybaka.admin' },
    ],
    whatsappMessage: 'halo\nsaya ingin membeli plugin "SussyBaka"',
  },
  {
    id: 'vulcan',
    name: 'Vulcan Anti Cheat',
    subtitle: 'Advanced packet-level cheat detection system untuk server Minecraft',
    tag: 'POPULAR',
    tagColor: 'orange',
    price: 'Rp 15.000',
    originalPrice: 'Rp 25.000',
    salesCount: 24,
    version: '1.8 - 26.1.2',
    category: 'Security',
    description: 'Sistem proteksi anti cheat berbasis packet level interception. Mendeteksi kecurangan combat, movement, dan player secara presisi tanpa beban lag server.',
    longDescription: 'Vulcan Anti Cheat adalah solusi proteksi server Minecraft berbasis packet level yang menganalisis lalu lintas data jaringan secara real-time. Dilengkapi puluhan check akurat untuk Combat (KillAura, Reach, Velocity), Movement (Flight, Speed, Jesus), serta Player exploits (Scaffold, BadPackets, Timer). Mendukung Judgement Day ban wave, silent setback, profiling latency koneksi pemain, dan integrasi Discord webhook. File .jar siap pakai langsung di server Anda tanpa memerlukan aktivasi kode lisensi.',
    colorScheme: {
      primary: '#F97316',
      secondary: '#EF4444',
      gradient: 'from-orange-500 via-amber-400 to-red-500',
    },
    features: [
      'Proteksi packet events berkecepatan tinggi dengan overhead tick server sangat rendah',
      'Combat checks presisi: deteksi KillAura, AimAssist, Reach, Velocity, AutoClicker, HitBox, dan Criticals',
      'Movement checks akurat: deteksi Flight, Speed, Jesus, NoSlowdown, HighJump, Spider, dan Elytra exploits',
      'Player dan exploit checks: deteksi Scaffold, FastEat, BadPackets, InventoryMove, Timer, dan Blink',
      'Judgement Day ban wave (/jday): eksekusi ban massal terjadwal untuk menyamarkan pola deteksi staf',
      'Analisis koneksi pemain (/vulcan connection): pantau transaction ping, flying delay, dan lag spike secara real-time',
      'Integrasi Discord webhook: kirim otomatis alert deteksi dan log hukuman pemain ke channel Discord Anda',
      'File .jar siap pakai: pasang langsung di folder plugins server tanpa perlu aktivasi lisensi',
    ],
    specs: [
      { label: 'Kompatibilitas Fork', value: 'Spigot, Paper, Purpur, Leaf, Folia, Gale (1.8 - 26.1.2)' },
      { label: 'Dependencies Wajib', value: 'PacketEvents' },
      { label: 'Metode Deteksi', value: 'Asynchronous Packet Interception' },
      { label: 'Integrasi Eksternal', value: 'Discord Webhook & BungeeCord / Velocity' },
      { label: 'Purchased', value: '24 purchased' },
    ],
    commands: [
      { cmd: '/vulcan gui', desc: 'Membuka menu in-game GUI pengaturan dan status checks', perm: 'vulcan.gui' },
      { cmd: '/vulcan alerts', desc: 'Mengaktifkan atau menonaktifkan notifikasi kecurangan in-game', perm: 'vulcan.alerts' },
      { cmd: '/vulcan logs <player>', desc: 'Melihat riwayat log pelanggaran pemain', perm: 'vulcan.logs' },
      { cmd: '/vulcan connection <player>', desc: 'Melihat analisis ping, latency transaksi, dan delay koneksi pemain', perm: 'vulcan.connection' },
      { cmd: '/jday', desc: 'Memulai atau mengelola antrean ban massal Vulcan Judgement Day', perm: 'vulcan.jday' },
      { cmd: '/vulcan reload', desc: 'Memuat ulang konfigurasi Vulcan config.yml', perm: 'vulcan.admin' },
    ],
    whatsappMessage: 'halo\nsaya ingin membeli plugin "Vulcan Anti Cheat"',
  },
];

export const FAQS = [
  {
    q: 'Bagaimana alur pembelian dan pengiriman file plugin?',
    a: 'Pilih plugin yang Anda inginkan, lalu klik tombol Order via WhatsApp untuk terhubung dengan Admin. Admin akan langsung mengirim berkas file .jar dan License Key aktivasi Anda setelah pembayaran.',
  },
  {
    q: 'Apakah plugin Sharket mendukung Folia dan Leaf?',
    a: 'Ya, seluruh plugin Sharket telah diuji dan dioptimalkan untuk lingkungan multi threaded Folia serta core Paper dan Leaf 1.21.x tanpa error scheduler.',
  },
  {
    q: 'Di mana saya harus memasukkan License Key?',
    a: 'Saat plugin pertama kali dijalankan di server, berkas plugins/SharketAuctions/license.yml akan otomatis dibuat dengan status kosong. Masukkan kode lisensi resmi yang Anda dapatkan dari Admin ke baris LICENSE-KEY: "KODE-LISENSI", lalu simpan berkas dan restart server.',
  },
  {
    q: 'Metode pembayaran apa saja yang diterima?',
    a: 'Kami menerima QRIS (semua e-wallet dan mobile banking), DANA, GoPay, OVO, serta Transfer Bank BCA, Mandiri, dan BRI.',
  },
  {
    q: 'Bagaimana sistem pembaruan (update) plugin?',
    a: 'User akan mendapatkan update secara berkala apabila ada pembaruan dari developer yang dibagikan secara langsung melalui channel WhatsApp resmi Sharket Plugin.',
  },
];
