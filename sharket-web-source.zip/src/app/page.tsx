'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import HeroBanner from '@/components/HeroBanner';
import FAQSection from '@/components/FAQSection';
import Footer from '@/components/Footer';
import OrderModal from '@/components/OrderModal';

export default function HomePage() {
  const [orderModalOpen, setOrderModalOpen] = useState(false);

  return (
    <div className="flex-1 flex flex-col">
      {/* Navbar */}
      <Navbar onOpenOrder={() => setOrderModalOpen(true)} />

      {/* Hero Banner with Pastel Letter Hover & Button to Plugins */}
      <HeroBanner />

      {/* FAQ Section */}
      <FAQSection onOpenOrder={() => setOrderModalOpen(true)} />

      {/* Footer */}
      <Footer onOpenOrder={() => setOrderModalOpen(true)} />

      {/* WhatsApp Order Modal */}
      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
      />
    </div>
  );
}
