'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import ProductCard from '@/components/ProductCard';
import Footer from '@/components/Footer';
import OrderModal from '@/components/OrderModal';
import { PLUGINS_DATA } from '@/data/plugins';
import { Sparkles } from 'lucide-react';

export default function PluginsPage() {
  const [orderModalOpen, setOrderModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-aquatic-grid text-[#002D47]">
      <Navbar onOpenOrder={() => setOrderModalOpen(true)} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link href="/" className="hover:text-sky-600 transition-colors">
            Beranda
          </Link>
          <span>/</span>
          <span className="font-semibold text-[#002D47]">Plugin</span>
        </nav>

        {/* Section Header (Clean, without the requested removed paragraph) */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-minecraft font-bold bg-sky-100 text-sky-800 border border-sky-200 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-sky-600" />
            Minecraft Plugin
          </div>
          <h1 className="font-minecraft text-3xl sm:text-4xl font-bold text-[#002D47] tracking-tight">
            Products
          </h1>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PLUGINS_DATA.map((plugin) => (
            <ProductCard
              key={plugin.id}
              plugin={plugin}
            />
          ))}
        </div>

      </main>

      <Footer onOpenOrder={() => setOrderModalOpen(true)} />

      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
      />
    </div>
  );
}
