'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import OrderModal from '@/components/OrderModal';
import { Send, CheckCircle2, AlertCircle } from 'lucide-react';

export default function SuggestionsPage() {
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setErrorMsg('Mohon isi judul dan deskripsi saran.');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    setSuccess(false);

    try {
      const res = await fetch('/api/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description }),
      });

      if (res.ok) {
        setSuccess(true);
        setTitle('');
        setDescription('');
      } else {
        const data = await res.json();
        setErrorMsg(data.error || 'Terjadi kesalahan saat mengirim saran.');
      }
    } catch {
      setErrorMsg('Gagal terhubung ke server. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-aquatic-grid text-[#002D47]">
      <Navbar onOpenOrder={() => setOrderModalOpen(true)} />

      <main className="flex-1 max-w-3xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link href="/" className="hover:text-sky-600 transition-colors">
            Beranda
          </Link>
          <span>/</span>
          <span className="font-semibold text-[#002D47]">Suggestion Plugin</span>
        </nav>

        {/* Header */}
        <div className="mb-8 text-center sm:text-left">
          <h1 className="font-minecraft text-3xl sm:text-4xl font-bold text-[#002D47] tracking-tight">
            Suggestion Plugin Baru
          </h1>
          <p className="text-sm text-slate-600 mt-2">
            Punya ide atau fitur plugin Minecraft yang ingin kami buat? Tuliskan judul dan deskripsi saran Anda di bawah.
          </p>
        </div>

        {/* Suggestion Form Container */}
        <div className="card-glass rounded-3xl p-6 sm:p-8 shadow-md">
          
          {success && (
            <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Saran Anda telah berhasil dikirim ke Admin. Terima kasih atas masukannya!</span>
            </div>
          )}

          {errorMsg && (
            <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-sm flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-[#002D47] uppercase tracking-wider mb-2">
                Judul
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="contoh:Team/Shop"
                required
                className="w-full text-sm font-medium px-4 py-3 rounded-xl border border-sky-200 focus:border-sky-500 focus:outline-none bg-sky-50/50 text-[#002D47]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#002D47] uppercase tracking-wider mb-2">
                Deskripsi:
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="jelaskan gambaran fitur dan alur kerja"
                rows={6}
                required
                className="w-full text-sm font-medium px-4 py-3 rounded-xl border border-sky-200 focus:border-sky-500 focus:outline-none bg-sky-50/50 text-[#002D47] leading-relaxed"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="mc-btn-primary px-8 py-3.5 rounded-xl text-white font-minecraft text-xs sm:text-sm font-bold flex items-center gap-2 shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{loading ? 'MENGIRIM...' : 'KIRIM SARAN'}</span>
              </button>
            </div>
          </form>
        </div>

      </main>

      <Footer onOpenOrder={() => setOrderModalOpen(true)} />

      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
      />
    </div>
  );
}
