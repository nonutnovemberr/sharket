'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import OrderModal from '@/components/OrderModal';
import { ShieldAlert, Ban, RefreshCw, CheckCircle2, FileText, ArrowLeft, ExternalLink } from 'lucide-react';

export default function TermsPage() {
  const [orderModalOpen, setOrderModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-aquatic-grid text-[#002D47]">
      <Navbar onOpenOrder={() => setOrderModalOpen(true)} />

      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link href="/" className="hover:text-sky-600 transition-colors">
            Beranda
          </Link>
          <span>/</span>
          <span className="font-semibold text-[#002D47]">Syarat &amp; Ketentuan</span>
        </nav>

        {/* Header */}
        <div className="mb-10 text-center sm:text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-minecraft font-bold bg-sky-100 text-sky-800 border border-sky-200 mb-3">
            <FileText className="w-3.5 h-3.5 text-sky-600" />
            LEGAL &amp; POLICIES
          </div>
          <h1 className="font-minecraft text-3xl sm:text-4xl font-bold text-[#002D47] tracking-tight">
            Syarat &amp; Ketentuan
          </h1>
          <p className="text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
            Harap baca syarat dan ketentuan berikut dengan seksama sebelum melakukan transaksi pembelian plugin di Sharket Plugin.
          </p>
        </div>

        {/* Terms Content Cards */}
        <div className="space-y-6">

          {/* Point 1: Kebijakan Pengembalian Dana (No Refund) */}
          <div className="card-glass rounded-3xl p-6 sm:p-8 shadow-sm border border-sky-200">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center shrink-0 mt-0.5">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h2 className="font-minecraft text-lg sm:text-xl font-bold text-[#002D47] mb-2">
                  1. Kebijakan Pengembalian Dana (No Refund)
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Seluruh pembelian bersifat final. Setelah file berkas <code className="bg-sky-50 text-sky-800 px-1.5 py-0.5 rounded text-xs font-mono font-bold">.jar</code> dan kode lisensi resmi dikirimkan oleh Admin kepada pembeli, pembayaran <strong>tidak dapat dikembalikan (No Refund)</strong> dalam bentuk apa pun dan dengan alasan apa pun.
                </p>
              </div>
            </div>
          </div>

          {/* Point 2: Larangan Redistribusi & Reselling */}
          <div className="card-glass rounded-3xl p-6 sm:p-8 shadow-sm border border-sky-200">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0 mt-0.5">
                <Ban className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h2 className="font-minecraft text-lg sm:text-xl font-bold text-[#002D47] mb-2">
                  2. Larangan Redistribusi, Decompile &amp; Penjualan Kembali
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3">
                  Pembeli dilarang keras untuk:
                </p>
                <ul className="list-disc pl-5 text-xs sm:text-sm text-slate-600 space-y-1.5 leading-relaxed">
                  <li>Membagikan ulang, mengunggah, atau membocorkan (*leak*) file <code className="bg-sky-50 text-sky-800 px-1 py-0.5 rounded text-xs font-mono font-bold">.jar</code> dan kode lisensi ke pihak ketiga maupun situs publik.</li>
                  <li>Melakukan decompile, reverse engineering, atau memodifikasi kode biner file plugin.</li>
                  <li>Menjual kembali (*reselling*) lisensi atau file plugin dengan cara apa pun.</li>
                </ul>
                <div className="mt-4 p-3.5 rounded-xl bg-rose-50/80 border border-rose-200 text-rose-900 text-xs leading-relaxed font-medium">
                  Pelanggaran terhadap ketentuan di atas akan berakibat pada <strong>pencabutan dan blacklist lisensi permanen</strong> tanpa pemberitahuan terlebih dahulu.
                </div>
              </div>
            </div>
          </div>

          {/* Point 3: Pembaruan Plugin (Update) */}
          <div className="card-glass rounded-3xl p-6 sm:p-8 shadow-sm border border-sky-200">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-sky-50 text-sky-600 border border-sky-200 flex items-center justify-center shrink-0 mt-0.5">
                <RefreshCw className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h2 className="font-minecraft text-lg sm:text-xl font-bold text-[#002D47] mb-2">
                  3. Pembaruan Plugin (Update Gratis Selamanya)
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Setiap pembeli resmi berhak mendapatkan pembaruan (update) plugin secara <strong>gratis selamanya</strong> yang dibagikan secara langsung melalui{' '}
                  <a
                    href="https://whatsapp.com/channel/0029Vb9CNokBFLgS3bTmwd3P"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-700 underline font-semibold inline-flex items-center gap-1 transition-colors"
                  >
                    <span>channel WhatsApp</span>
                    <ExternalLink className="w-3 h-3 inline" />
                  </a>{' '}
                  resmi Sharket Plugin.
                </p>
              </div>
            </div>
          </div>

          {/* Point 4: Persetujuan Pengguna */}
          <div className="card-glass rounded-3xl p-6 sm:p-8 shadow-sm border border-sky-200">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h2 className="font-minecraft text-lg sm:text-xl font-bold text-[#002D47] mb-2">
                  4. Penerimaan Ketentuan
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Dengan melanjutkan proses pemesanan dan melakukan pembayaran lisensi plugin Sharket, Anda menyatakan telah membaca, memahami, dan menyetujui seluruh Syarat &amp; Ketentuan yang tertera di atas secara sadar dan tanpa paksaan.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Back Link */}
        <div className="mt-10 flex justify-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#002D47] hover:text-sky-600 transition-colors px-5 py-2.5 rounded-xl bg-white/80 border border-sky-200 shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Beranda</span>
          </Link>
        </div>

      </main>

      <Footer onOpenOrder={() => setOrderModalOpen(true)} />

      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
      />
    </div>
  );
}
