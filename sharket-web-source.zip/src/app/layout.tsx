import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sharket Plugin - Jual Plugin Keren!",
  description: "Beli plugin Minecraft SharketAuctions, SussyBaka, dan Vulcan Anti Cheat. Berperforma tinggi, 100% Anti Dupe, Folia Ready & Koleksi Terpercaya.",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <link href="https://fonts.cdnfonts.com/css/minecraftia" rel="stylesheet" />
        <link href="https://fonts.cdnfonts.com/css/minecraft-ten" rel="stylesheet" />
      </head>
      <body className="min-h-screen bg-aquatic-grid text-[#002D47] flex flex-col antialiased">
        {children}
      </body>
    </html>
  );
}
