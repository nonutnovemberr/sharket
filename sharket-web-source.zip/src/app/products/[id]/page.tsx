import { notFound } from 'next/navigation';
import { PLUGINS_DATA } from '@/data/plugins';
import ProductDetailClient from '@/components/ProductDetailClient';
import type { Metadata } from 'next';

export function generateStaticParams() {
  return PLUGINS_DATA.map((plugin) => ({
    id: plugin.id,
  }));
}

interface PageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const plugin = PLUGINS_DATA.find((p) => p.id === id);

  if (!plugin) {
    return {
      title: 'Plugin Not Found - Sharket Plugin',
    };
  }

  return {
    title: `${plugin.name} - Sharket Plugin Store`,
    description: plugin.subtitle,
  };
}

export default async function ProductDetailPage({ params }: PageProps) {
  const { id } = await params;
  const plugin = PLUGINS_DATA.find((p) => p.id === id);

  if (!plugin) {
    notFound();
  }

  return <ProductDetailClient plugin={plugin} />;
}
