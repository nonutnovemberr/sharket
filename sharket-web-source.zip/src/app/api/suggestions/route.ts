import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const DATA_FILE = path.join(process.cwd(), 'src', 'data', 'suggestions.json');

export interface SuggestionItem {
  id: string;
  title: string;
  description: string;
  createdAt: string;
}

function readSuggestions(): SuggestionItem[] {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, '[]', 'utf-8');
      return [];
    }
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(data || '[]');
  } catch (error) {
    console.error('Error reading suggestions file:', error);
    return [];
  }
}

function writeSuggestions(items: SuggestionItem[]) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error writing suggestions file:', error);
  }
}

// GET /api/suggestions - retrieve suggestions list
export async function GET() {
  const items = readSuggestions();
  // Return newest first
  return NextResponse.json(items.reverse());
}

// POST /api/suggestions - submit new plugin suggestion
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { title, description } = body;

    if (!title || !description || !title.trim() || !description.trim()) {
      return NextResponse.json(
        { error: 'Judul dan deskripsi saran wajib diisi.' },
        { status: 400 }
      );
    }

    const items = readSuggestions();
    const newItem: SuggestionItem = {
      id: Date.now().toString(),
      title: title.trim(),
      description: description.trim(),
      createdAt: new Date().toISOString(),
    };

    items.push(newItem);
    writeSuggestions(items);

    return NextResponse.json({ success: true, item: newItem }, { status: 201 });
  } catch (error) {
    console.error('POST suggestions error:', error);
    return NextResponse.json(
      { error: 'Gagal menyimpan saran. Silakan coba lagi.' },
      { status: 500 }
    );
  }
}

// DELETE /api/suggestions - delete suggestion (Admin only with PIN)
export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    const pin = searchParams.get('pin');

    if (pin !== 'sharket2026') {
      return NextResponse.json({ error: 'PIN Admin tidak valid' }, { status: 403 });
    }

    if (!id) {
      return NextResponse.json({ error: 'ID saran diperlukan' }, { status: 400 });
    }

    let items = readSuggestions();
    items = items.filter((item) => item.id !== id);
    writeSuggestions(items);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE suggestion error:', error);
    return NextResponse.json({ error: 'Gagal menghapus saran' }, { status: 500 });
  }
}
