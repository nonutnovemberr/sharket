'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import OrderModal from '@/components/OrderModal';
import { Lock, Trash2, RefreshCw, KeyRound, ArrowLeft, Shield } from 'lucide-react';

interface Suggestion {
  id: string;
  title: string;
  description: string;
  createdAt: string;
}

export default function AdminSuggestionsPage() {
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [pinError, setPinError] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchSuggestions = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/suggestions');
      if (res.ok) {
        const data = await res.json();
        setSuggestions(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Check session storage
    if (typeof window !== 'undefined') {
      const savedPin = sessionStorage.getItem('admin_pin');
      if (savedPin === 'sharket2026') {
        setAuthenticated(true);
      }
    }
  }, []);

  useEffect(() => {
    if (authenticated) {
      fetchSuggestions();
    }
  }, [authenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === 'sharket2026') {
      setAuthenticated(true);
      sessionStorage.setItem('admin_pin', 'sharket2026');
      setPinError(false);
    } else {
      setPinError(true);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus saran ini?')) return;

    try {
      const res = await fetch(`/api/suggestions?id=${id}&pin=sharket2026`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setSuggestions((prev) => prev.filter((s) => s.id !== id));
      } else {
        alert('Gagal menghapus saran');
      }
    } catch {
      alert('Terjadi kesalahan koneksi');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('admin_pin');
    setAuthenticated(false);
    setPinInput('');
  };

  return (
    <div className="min-h-screen flex flex-col bg-aquatic-grid text-[#002D47]">
      <Navbar onOpenOrder={() => setOrderModalOpen(true)} />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link href="/" className="hover:text-sky-600 transition-colors">
            Beranda
          </Link>
          <span>/</span>
          <span className="font-semibold text-[#002D47]">Admin Dashboard</span>
        </nav>

        {!authenticated ? (
          /* Admin Login PIN Box */
          <div className="max-w-md mx-auto my-12 card-glass rounded-3xl p-8 shadow-xl text-center">
            <div className="w-14 h-14 rounded-2xl bg-sky-100 flex items-center justify-center mx-auto mb-4 text-[#002D47]">
              <Lock className="w-7 h-7 text-sky-700" />
            </div>
            
            <h1 className="font-minecraft text-xl font-bold text-[#002D47] mb-1">
              Admin Suggestions Portal
            </h1>
            <p className="text-xs text-slate-500 mb-6">
              Masukkan PIN Admin untuk melihat saran yang masuk dari pengguna.
            </p>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Masukkan PIN Admin"
                  autoFocus
                  required
                  className="w-full text-center font-mono text-base px-4 py-3 rounded-xl border border-sky-300 focus:border-sky-500 focus:outline-none bg-sky-50/60"
                />
                {pinError && (
                  <p className="text-xs text-rose-600 font-semibold mt-2">
                    PIN Admin salah. Silakan coba lagi.
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="mc-btn-primary w-full py-3 rounded-xl text-white font-minecraft text-xs font-bold shadow-md cursor-pointer"
              >
                MASUK KE DASHBOARD
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Admin Dashboard */
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
              <div>
                <h1 className="font-minecraft text-2xl sm:text-3xl font-bold text-[#002D47]">
                  Daftar Saran Plugin ({suggestions.length})
                </h1>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  Semua ide dan saran plugin yang dikirimkan oleh pengguna website.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={fetchSuggestions}
                  disabled={loading}
                  className="px-4 py-2 rounded-xl bg-white border border-sky-200 text-xs font-semibold text-[#002D47] flex items-center gap-1.5 hover:bg-sky-50 transition-colors shadow-xs cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
                >
                  Keluar
                </button>
              </div>
            </div>

            {/* Suggestions Table / Cards */}
            {suggestions.length === 0 ? (
              <div className="card-glass rounded-3xl p-12 text-center text-slate-500">
                <p className="font-minecraft text-base">Belum ada saran plugin yang masuk.</p>
                <p className="text-xs mt-1">Saran dari pengguna akan otomatis muncul di halaman ini.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {suggestions.map((item, idx) => (
                  <div
                    key={item.id}
                    className="card-glass rounded-2xl p-6 shadow-xs border border-sky-200/90 relative group transition-all hover:border-sky-400"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="font-minecraft text-xs bg-sky-100 text-sky-800 px-2 py-0.5 rounded font-bold">
                            #{suggestions.length - idx}
                          </span>
                          <h2 className="font-minecraft text-lg font-bold text-[#002D47]">
                            {item.title}
                          </h2>
                        </div>
                        <span className="text-[11px] text-slate-400 block mt-1">
                          Waktu kirim: {new Date(item.createdAt).toLocaleString('id-ID')}
                        </span>
                      </div>

                      <button
                        onClick={() => handleDelete(item.id)}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Hapus saran ini"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="mt-4 pt-3 border-t border-sky-100 bg-sky-50/50 p-4 rounded-xl text-xs sm:text-sm text-[#002D47] leading-relaxed whitespace-pre-line">
                      {item.description}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </main>

      <Footer onOpenOrder={() => setOrderModalOpen(true)} />

      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
      />
    </div>
  );
}
