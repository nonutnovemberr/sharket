'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

interface FooterProps {
  onOpenOrder?: () => void;
}

export default function Footer({ onOpenOrder }: FooterProps) {
  return (
    <footer className="relative bg-gradient-to-b from-[#00263d] via-[#001c2e] to-[#001320] text-sky-100 border-t-2 border-sky-400/30 pt-12 pb-8 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Row: Left Logo, Right Quicklinks */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 pb-10 border-b border-sky-800/60">
          
          {/* Left: Brand Logo & Title */}
          <div className="flex items-center gap-3.5">
            <div className="relative w-14 h-9 sm:w-16 sm:h-10 flex items-center justify-center shrink-0">
              <Image
                src="/images/shark-logo.png"
                alt="Sharket Logo"
                fill
                className="object-contain drop-shadow-md"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-minecraft text-xl font-bold tracking-tight">
                <span className="text-[#7DD3FC]">SHARKET</span>
                <span className="text-[#FEF08A]">PLUGIN</span>
              </div>
              <span className="text-xs text-sky-300/80 font-medium">
                High Performance Minecraft Systems
              </span>
            </div>
          </div>

          {/* Quicklinks (2 Columns, 3 items downwards per column) */}
          <div className="grid grid-cols-2 gap-x-10 sm:gap-x-16 gap-y-2.5 text-xs sm:text-sm font-semibold text-sky-200">
            <div className="flex flex-col gap-2.5">
              <Link href="/" className="hover:text-yellow-200 transition-colors">
                Beranda
              </Link>
              <Link href="/plugins" className="hover:text-yellow-200 transition-colors">
                Plugin
              </Link>
              <Link href="/suggestions" className="hover:text-yellow-200 transition-colors">
                Suggestion
              </Link>
            </div>
            <div className="flex flex-col gap-2.5">
              <Link href="/#faq" className="hover:text-yellow-200 transition-colors">
                FAQ
              </Link>
              <a
                href="https://whatsapp.com/channel/0029Vb9CNokBFLgS3bTmwd3P"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-yellow-200 transition-colors"
              >
                Channel WhatsApp
              </a>
              <a
                href="https://discord.com/users/waitingforthissolong"
                target="_blank"
                rel="noopener noreferrer"
                title="Discord"
                className="hover:text-yellow-200 transition-colors"
              >
                Discord
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright, Terms & Disguised Admin Link */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-sky-300/70 font-medium">
          <div className="flex items-center gap-3">
            <p>&copy; 2026 Sharket Plugin</p>
            <span>•</span>
            <Link
              href="/terms"
              className="text-sky-300 hover:text-yellow-200 transition-colors font-medium underline-offset-4 hover:underline"
            >
              Syarat &amp; Ketentuan
            </Link>
          </div>

          {/* Disguised / Camouflaged Admin Suggestions Link */}
          <Link
            href="/admin/suggestions"
            className="text-sky-950/20 hover:text-sky-400/60 transition-colors text-[10px] select-none"
            title="Portal"
          >
            admin panel
          </Link>
        </div>

      </div>
    </footer>
  );
}
