'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { MessageCircle, Menu, X, ShoppingBag } from 'lucide-react';

interface NavbarProps {
  onOpenOrder?: (pluginId?: string) => void;
}

export default function Navbar({ onOpenOrder }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  const isHome = pathname === '/';
  const isPlugins = pathname === '/plugins' || pathname.startsWith('/products');
  const isSuggestions = pathname === '/suggestions';

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-white/90 border-b border-sky-200/90 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo with Floating & Hover Animation */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative w-14 h-9 sm:w-16 sm:h-10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-300">
              <Image
                src="/images/shark-logo.png"
                alt="Sharket Logo"
                fill
                priority
                className="object-contain drop-shadow-md"
              />
            </div>
            <div className="flex items-center gap-1.5 font-minecraft text-xl sm:text-2xl font-bold tracking-tight">
              <span className="text-[#7DD3FC] drop-shadow-sm group-hover:text-sky-300 group-hover:-translate-y-0.5 transition-all duration-200">
                SHARKET
              </span>
              <span className="text-[#FEF08A] drop-shadow-sm group-hover:text-yellow-100 group-hover:-translate-y-0.5 transition-all duration-200" style={{ transitionDelay: '50ms' }}>
                PLUGIN
              </span>
            </div>
          </Link>

          {/* Desktop Nav Items with Animated Pills */}
          <nav className="hidden md:flex items-center gap-2 bg-sky-100/80 p-1.5 rounded-2xl border border-sky-200 text-sm font-semibold text-[#002D47] shadow-inner">
            <Link
              href="/"
              className={`px-5 py-2 rounded-xl transition-all duration-200 transform hover:scale-105 active:scale-95 ${
                isHome
                  ? 'bg-[#00BDF6] text-white shadow-md shadow-sky-400/40 font-bold'
                  : 'hover:bg-sky-200/70 text-[#002D47]'
              }`}
            >
              Beranda
            </Link>
            <Link
              href="/plugins"
              className={`px-5 py-2 rounded-xl transition-all duration-200 transform hover:scale-105 active:scale-95 ${
                isPlugins
                  ? 'bg-[#00BDF6] text-white shadow-md shadow-sky-400/40 font-bold'
                  : 'hover:bg-sky-200/70 text-[#002D47]'
              }`}
            >
              Plugin
            </Link>
            <Link
              href="/suggestions"
              className={`px-5 py-2 rounded-xl transition-all duration-200 transform hover:scale-105 active:scale-95 ${
                isSuggestions
                  ? 'bg-[#00BDF6] text-white shadow-md shadow-sky-400/40 font-bold'
                  : 'hover:bg-sky-200/70 text-[#002D47]'
              }`}
            >
              Suggestion
            </Link>
            <Link
              href="/#faq"
              className="px-5 py-2 rounded-xl hover:bg-sky-200/70 text-[#002D47] transition-all duration-200 transform hover:scale-105 active:scale-95"
            >
              FAQ
            </Link>
          </nav>

          {/* Desktop Action Buttons with Hover Animations & Shimmer */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href="https://discord.com/users/waitingforthissolong"
              target="_blank"
              rel="noopener noreferrer"
              title="Discord: waitingforthissolong"
              className="group px-4 py-2.5 rounded-xl border border-sky-300 bg-sky-50 hover:bg-[#5865F2] hover:text-white text-[#002D47] text-xs font-semibold flex items-center gap-2 transition-all duration-200 hover:scale-105 active:scale-95 shadow-xs hover:shadow-indigo-300/50"
            >
              <svg className="w-4 h-4 fill-[#5865F2] group-hover:fill-white group-hover:-rotate-12 transition-all duration-200" viewBox="0 0 24 24">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
              </svg>
              <span>Discord</span>
            </a>

            <Link
              href="/plugins"
              className="mc-btn-primary animate-shimmer text-white text-xs sm:text-sm font-minecraft font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 cursor-pointer shadow-md hover:scale-105 active:scale-95 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>ORDER SEKARANG</span>
            </Link>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-sky-100 text-[#002D47] hover:bg-sky-200 transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-md border-b border-sky-200 px-6 py-5 space-y-4 shadow-xl animate-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-2 font-semibold text-[#002D47]">
            <Link 
              href="/" 
              onClick={() => setMobileMenuOpen(false)}
              className={`p-2.5 rounded-xl transition-colors ${
                isHome ? 'bg-[#00BDF6] text-white font-bold' : 'hover:bg-sky-50'
              }`}
            >
              Beranda
            </Link>
            <Link 
              href="/plugins" 
              onClick={() => setMobileMenuOpen(false)}
              className={`p-2.5 rounded-xl transition-colors ${
                isPlugins ? 'bg-[#00BDF6] text-white font-bold' : 'hover:bg-sky-50'
              }`}
            >
              Plugin
            </Link>
            <Link 
              href="/suggestions" 
              onClick={() => setMobileMenuOpen(false)}
              className={`p-2.5 rounded-xl transition-colors ${
                isSuggestions ? 'bg-[#00BDF6] text-white font-bold' : 'hover:bg-sky-50'
              }`}
            >
              Suggestion
            </Link>
            <Link 
              href="/#faq" 
              onClick={() => setMobileMenuOpen(false)}
              className="p-2.5 hover:bg-sky-50 rounded-xl transition-colors"
            >
              FAQ
            </Link>
          </nav>

          <div className="pt-2 border-t border-sky-100 flex flex-col gap-2">
            <Link
              href="/plugins"
              onClick={() => setMobileMenuOpen(false)}
              className="mc-btn-primary w-full text-white text-sm font-minecraft font-bold py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>ORDER SEKARANG</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
