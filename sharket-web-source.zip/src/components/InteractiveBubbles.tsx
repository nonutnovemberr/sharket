'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { usePathname } from 'next/navigation';

interface Bubble {
  id: number;
  left: number;       // % across container (6% to 92%)
  size: number;       // px (22 to 44)
  duration: number;   // seconds to rise (5s to 8s)
  delay: number;      // initial start delay in seconds
  bursting: boolean;
}

export default function InteractiveBubbles() {
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const pathname = usePathname();

  // Clear bubbles immediately when route changes
  useEffect(() => {
    setBubbles([]);
  }, [pathname]);

  // Synthesize realistic bubble pop sound via Web Audio API
  const playPopSound = useCallback(() => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(700 + Math.random() * 140, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, ctx.currentTime + 0.08);
      
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch {
      // Audio not supported
    }
  }, []);

  useEffect(() => {
    // Mobile optimization: 5 bubbles on mobile, 7 on desktop
    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const bubbleCount = isMobile ? 5 : 7;

    const initialBubbles: Bubble[] = Array.from({ length: bubbleCount }).map((_, i) => ({
      id: i + 1,
      left: Math.floor(Math.random() * 84) + 8,
      size: Math.floor(Math.random() * 22) + 22, // 22px to 44px
      duration: Number((Math.random() * 2.5 + 5.5).toFixed(1)), // 5.5s to 8s
      delay: Number((Math.random() * 3.5).toFixed(1)),
      bursting: false,
    }));

    setBubbles(initialBubbles);

    // If user clicks any navigation link or anchor, immediately wipe bubbles
    const handleNavClick = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest('a, button');
      if (target) {
        setBubbles([]);
      }
    };

    window.addEventListener('click', handleNavClick, { passive: true });

    return () => {
      window.removeEventListener('click', handleNavClick);
      setBubbles([]);
    };
  }, [pathname]);

  const handlePop = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    e.preventDefault();

    playPopSound();

    // Mark as bursting
    setBubbles((prev) =>
      prev.map((b) => (b.id === id ? { ...b, bursting: true } : b))
    );

    // After burst animation completes (180ms), respawn from bottom with delay 0
    setTimeout(() => {
      setBubbles((prev) =>
        prev.map((b) =>
          b.id === id
            ? {
                ...b,
                left: Math.floor(Math.random() * 84) + 8,
                size: Math.floor(Math.random() * 22) + 22,
                duration: Number((Math.random() * 2.5 + 5.5).toFixed(1)),
                delay: 0,
                bursting: false,
              }
            : b
        )
      );
    }, 200);
  };

  if (bubbles.length === 0) return null;

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-30 contain-paint">
      {bubbles.map((b) => (
        <button
          key={b.id}
          type="button"
          onClick={(e) => handlePop(e, b.id)}
          onMouseDown={(e) => handlePop(e, b.id)}
          title="Klik untuk meletuskan gelembung!"
          className={`bubble-gpu pointer-events-auto cursor-pointer focus:outline-none touch-manipulation ${
            b.bursting ? 'bubble-burst-gpu' : ''
          }`}
          style={{
            left: `${b.left}%`,
            width: `${b.size}px`,
            height: `${b.size}px`,
            animationDuration: `${b.duration}s`,
            animationDelay: `${b.delay}s`,
          }}
        >
          {/* Subtle light reflection on the bubble */}
          <span className="absolute top-1 left-1.5 w-1/3 h-1/3 rounded-full bg-white/75 block pointer-events-none" />
        </button>
      ))}
    </div>
  );
}
