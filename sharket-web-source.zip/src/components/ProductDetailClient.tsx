'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { PluginItem } from '@/data/plugins';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import OrderModal from '@/components/OrderModal';
import PluginMediaGallery from '@/components/PluginMediaGallery';
import BundlePromoCard from '@/components/BundlePromoCard';
import { 
  ArrowLeft, 
  Check, 
  Copy, 
  Terminal, 
  ShieldCheck, 
  MessageCircle,
  ShoppingBag
} from 'lucide-react';

interface ProductDetailClientProps {
  plugin: PluginItem;
}

export default function ProductDetailClient({ plugin }: ProductDetailClientProps) {
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const isAuction = plugin.id === 'sharket-auctions';

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-aquatic-grid text-[#002D47]">
      <Navbar onOpenOrder={() => setOrderModalOpen(true)} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        
        {/* BuiltByBit-style Breadcrumbs */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link href="/" className="hover:text-sky-600 transition-colors">
            Beranda
          </Link>
          <span>/</span>
          <Link href="/plugins" className="hover:text-sky-600 transition-colors">
            Products
          </Link>
          <span>/</span>
          <span className="font-semibold text-[#002D47]">{plugin.name}</span>
        </nav>

        {/* Resource Header (BuiltByBit Style) */}
        <div className="card-glass rounded-3xl p-6 sm:p-8 mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center gap-5">
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden shrink-0 border border-sky-200 shadow-md bg-slate-900">
                <Image
                  src={plugin.id === 'vulcan' ? '/images/vulcan/display.jpg' : `/images/${plugin.id}/banner-official.jpg`}
                  alt={plugin.name}
                  fill
                  className="object-cover object-center"
                />
              </div>
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h1 className="font-minecraft text-2xl sm:text-3xl font-bold text-[#002D47]">
                    {plugin.name}
                  </h1>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded bg-sky-100 text-sky-800 border border-sky-200">
                    {plugin.tag}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mt-1">
                  {plugin.subtitle}
                </p>
                <div className="flex items-center gap-3 sm:gap-4 text-xs text-slate-500 mt-2 font-medium flex-wrap">
                  <span>Supported: <strong className="text-sky-800">{plugin.version}</strong></span>
                  <span>•</span>
                  <span>Kompatibilitas: <strong className="text-emerald-700">{plugin.id === 'vulcan' ? 'Spigot, Paper, Purpur, Leaf, Folia, Gale, Bungee, Velocity' : 'Paper, Purpur, Leaf, Pufferfish, Folia, Gale'}</strong></span>
                </div>
              </div>
            </div>

            <a
              href={`https://wa.me/628134784046?text=${encodeURIComponent(plugin.whatsappMessage)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mc-btn-primary w-full sm:w-auto text-white font-minecraft text-xs sm:text-sm font-bold px-8 py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-md cursor-pointer shrink-0 hover:scale-105 active:scale-95 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Buy</span>
            </a>
          </div>
        </div>

        {/* 2-Column BuiltByBit Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content Column (Left) */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Overview / Description */}
            <div className="card-glass rounded-3xl p-6 sm:p-8">
              {/* BuiltByBit-Style Interactive Screenshot Slideshow */}
              <PluginMediaGallery pluginName={plugin.name} />

              <h2 className="font-minecraft text-lg font-bold text-[#002D47] mb-4">
                Deskripsi Plugin
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {plugin.longDescription}
              </p>

              {/* Feature List (Clean without emoji spam) */}
              <h3 className="font-minecraft text-base font-bold text-[#002D47] mt-8 mb-4">
                Fitur Unggulan
              </h3>
              <div className="space-y-3">
                {plugin.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-3 text-sm text-[#002D47]">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 border border-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5 text-emerald-700" />
                    </div>
                    <span className="font-medium">{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Commands & Permissions */}
            <div className="card-glass rounded-3xl p-6 sm:p-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-minecraft text-lg font-bold text-[#002D47]">
                  Commands & Permissions
                </h2>
                <span className="text-xs text-slate-400">Klik baris untuk menyalin</span>
              </div>

              <div className="space-y-2.5">
                {plugin.commands.map((cmd, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleCopy(cmd.cmd)}
                    className="bg-[#0b1b26] p-3.5 rounded-xl border border-sky-900/60 flex items-center justify-between group hover:border-amber-400 cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <Terminal className="w-4 h-4 text-amber-400 shrink-0" />
                      <div>
                        <span className="font-mono-code text-xs sm:text-sm text-sky-200 font-bold block">
                          {cmd.cmd}
                        </span>
                        <span className="text-xs text-slate-400 block mt-0.5">
                          {cmd.desc}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono-code bg-sky-950 text-sky-300 px-2 py-0.5 rounded border border-sky-800">
                        {cmd.perm}
                      </span>
                      <button className="text-sky-400 hover:text-white p-1">
                        {copiedCmd === cmd.cmd ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Placeholders (PlaceholderAPI) */}
            {plugin.placeholders && plugin.placeholders.length > 0 && (
              <div className="card-glass rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-minecraft text-lg font-bold text-[#002D47]">
                    Placeholders
                  </h2>
                  <span className="text-xs text-slate-400">Klik baris untuk menyalin</span>
                </div>

                <div className="space-y-2.5">
                  {plugin.placeholders.map((ph, idx) => (
                    <div
                      key={idx}
                      onClick={() => handleCopy(ph.placeholder)}
                      className="bg-[#0b1b26] p-3.5 rounded-xl border border-sky-900/60 flex items-center justify-between group hover:border-sky-400 cursor-pointer transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-sky-400 font-mono font-bold text-sm shrink-0">%</span>
                        <div>
                          <span className="font-mono-code text-xs sm:text-sm text-sky-200 font-bold block">
                            {ph.placeholder}
                          </span>
                          <span className="text-xs text-slate-400 block mt-0.5">
                            {ph.desc}
                          </span>
                        </div>
                      </div>
                      <button className="text-sky-400 hover:text-white p-1">
                        {copiedCmd === ph.placeholder ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Specifications Table removed per user request */}
          </div>

          {/* Sidebar Column (Right - BuiltByBit Style) */}
          <div className="space-y-6">
            
            {/* 1. Purchase Box (Harga) */}
            <div className="card-glass rounded-3xl p-6 border-2 border-sky-300 shadow-lg">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Price
              </span>
              <div className="flex items-baseline gap-2.5 mt-1 mb-4">
                <span className="font-minecraft text-3xl font-bold text-emerald-600">
                  {plugin.price}
                </span>
                <span className="text-sm line-through text-red-500 font-semibold">
                  {plugin.originalPrice}
                </span>
              </div>

              <a
                href={`https://wa.me/628134784046?text=${encodeURIComponent(plugin.whatsappMessage)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="mc-btn-primary w-full text-white font-minecraft text-xs sm:text-sm font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-md cursor-pointer mb-3 hover:scale-105 active:scale-95 transition-all text-center"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Buy</span>
              </a>

              <div className="text-[11px] text-slate-500 space-y-1.5 pt-3 border-t border-sky-100">
                <div className="flex items-center gap-2 text-emerald-700 font-semibold">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>
                    {plugin.id === 'vulcan'
                      ? 'Pengiriman Instan File .jar Resmi'
                      : 'Pengiriman Instan File .jar & Lisensi'}
                  </span>
                </div>
                <p>
                  {plugin.id === 'vulcan'
                    ? 'Klik tombol Buy untuk diarahkan ke WhatsApp Admin. Setelah melakukan pembayaran, file .jar resmi siap pakai akan langsung diberikan oleh Admin tanpa memerlukan kode lisensi.'
                    : 'Klik tombol Buy untuk diarahkan ke WhatsApp Admin. Setelah melakukan pembayaran, file .jar dan kode lisensi resmi akan langsung diberikan oleh Admin.'}
                </p>
              </div>
            </div>

            {/* 2. Promo Bundling (Bundling - SussyBaka + Vulcan) */}
            {(plugin.id === 'sussy-baka' || plugin.id === 'vulcan') && (
              <BundlePromoCard />
            )}

            {/* 3. Resource Information Card (Informasi Resource) */}
            <div className="card-glass rounded-3xl p-6 text-xs sm:text-sm space-y-3">
              <h3 className="font-minecraft font-bold text-base text-[#002D47] mb-3">
                Informasi Resource
              </h3>
              
              <div className="flex justify-between py-1.5 border-b border-sky-100">
                <span className="text-slate-500">Kategori</span>
                <span className="font-semibold text-[#002D47]">{plugin.category}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-sky-100">
                <span className="text-slate-500">Versi Minecraft</span>
                <span className="font-semibold text-[#002D47]">{plugin.version}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-sky-100 gap-2">
                <span className="text-slate-500 shrink-0">Kompatibilitas</span>
                <span className="font-semibold text-[#002D47] text-right">
                  {plugin.id === 'vulcan'
                    ? 'Spigot, Paper, Purpur, Leaf, Folia, Gale, Bungee, Velocity'
                    : 'Paper, Purpur, Leaf, Pufferfish, Folia, Gale'}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-sky-100 gap-2">
                <span className="text-slate-500 shrink-0">Dependencies</span>
                <span className="font-semibold text-[#002D47] text-right">
                  {plugin.id === 'sharket-auctions'
                    ? 'Vault (Wajib), PlaceholderAPI (Opsional)'
                    : plugin.id === 'sharket-crates'
                    ? 'PlaceholderAPI (Wajib)'
                    : plugin.id === 'sussy-baka'
                    ? 'Anti Cheat (Vulcan, GrimAC, dll)'
                    : 'PacketEvents (Wajib)'}
                </span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-500">Purchased</span>
                <span className="font-semibold text-emerald-700">{plugin.salesCount} purchased</span>
              </div>
            </div>

            {/* Back to Products */}
            <Link
              href="/plugins"
              className="w-full py-3 px-4 rounded-2xl bg-white border border-sky-200 text-[#002D47] font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 hover:bg-sky-50 transition-colors block text-center shadow-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali ke Semua Produk</span>
            </Link>

          </div>

        </div>

      </main>

      <Footer onOpenOrder={() => setOrderModalOpen(true)} />

      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
        defaultPluginId={plugin.id}
      />
    </div>
  );
}
