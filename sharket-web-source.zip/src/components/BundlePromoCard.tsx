'use client';

import React from 'react';
import Image from 'next/image';
import { ShoppingBag, Sparkles, Check } from 'lucide-react';

export default function BundlePromoCard() {
  const whatsappUrl = `https://wa.me/628134784046?text=${encodeURIComponent('halo\nsaya ingin membeli paket bundle "SussyBaka + Vulcan Anti Cheat" (Rp 30.000)')}`;

  return (
    <div className="card-glass rounded-3xl p-5 sm:p-6 border-2 border-amber-300 shadow-lg relative overflow-hidden bg-gradient-to-b from-white via-amber-50/20 to-sky-50/30">
      {/* Top Ambient Glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-amber-300/20 rounded-full blur-2xl pointer-events-none" />

      {/* Header: Title & Discount Pill */}
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-sky-600" />
          <h4 className="font-bold text-sky-700 text-sm tracking-tight">
            Bundle and save
          </h4>
        </div>
        <span className="bg-red-500 text-white font-minecraft text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-xs tracking-wider animate-pulse">
          25% OFF
        </span>
      </div>

      {/* BuiltByBit Reference 1: Stacked Cards Visual Preview */}
      <div className="relative w-full aspect-[16/9] rounded-2xl bg-slate-950 p-2 overflow-hidden border border-slate-800 shadow-inner group">
        {/* Background Card (Vulcan Banner - Offset & Tilted) */}
        <div className="absolute inset-x-4 bottom-1 top-2 rounded-xl overflow-hidden opacity-50 transform -rotate-3 scale-95 border border-white/10 transition-transform group-hover:-rotate-4 duration-300">
          <Image
            src="/images/vulcan/display.jpg"
            alt="Vulcan Anti Cheat"
            fill
            className="object-cover object-center"
          />
        </div>

        {/* Front Card (SussyBaka Banner - Dominant & Focused) */}
        <div className="relative w-full h-full rounded-xl overflow-hidden border border-white/20 shadow-2xl">
          <Image
            src="/images/sussy-baka/banner-official.jpg"
            alt="SussyBaka"
            fill
            className="object-cover object-center group-hover:scale-105 transition-transform duration-300"
          />

          {/* Reference 1 Overlay Badges */}
          {/* Top-Left 25% Off Badge */}
          <div className="absolute top-2 left-2 bg-red-600/95 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/20 shadow-md">
            <span className="font-minecraft text-[10px] font-bold text-white tracking-wider">
              25% off
            </span>
          </div>

          {/* Bottom-Right Price Tag */}
          <div className="absolute bottom-2 right-2 bg-black/85 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/20 shadow-md text-right">
            <span className="text-[10px] text-red-400 line-through mr-1.5 font-medium">
              Rp 40.000
            </span>
            <span className="font-minecraft text-xs font-bold text-emerald-400">
              Rp 30.000
            </span>
          </div>
        </div>
      </div>

      {/* Bundle Title & Subtitle */}
      <div className="mt-3 text-center">
        <h5 className="font-bold text-[#002D47] text-sm tracking-tight">
          Staff Security Essentials
        </h5>
        <p className="text-[11px] text-slate-500 mt-0.5">
          SussyBaka + Vulcan Anti Cheat
        </p>
      </div>

      {/* BuiltByBit Reference 2: Included Plugins List */}
      <div className="mt-4 pt-3.5 border-t border-amber-200/60 space-y-2.5">
        {/* Item 1: SussyBaka */}
        <div className="flex items-center justify-between gap-2.5 p-2 rounded-xl bg-white/80 border border-sky-100 shadow-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative w-10 h-7 rounded-lg overflow-hidden shrink-0 border border-slate-200 bg-slate-900">
              <Image
                src="/images/sussy-baka/banner-official.jpg"
                alt="SussyBaka"
                fill
                className="object-cover"
              />
            </div>
            <div className="min-w-0">
              <span className="font-semibold text-xs text-[#002D47] block truncate">
                SussyBaka
              </span>
              <span className="text-[10px] text-slate-500 block">
                Investigation GUI Dashboard
              </span>
            </div>
          </div>
          <span className="text-xs font-bold text-slate-700 shrink-0">
            Rp 24.999
          </span>
        </div>

        {/* Item 2: Vulcan Anti Cheat */}
        <div className="flex items-center justify-between gap-2.5 p-2 rounded-xl bg-white/80 border border-sky-100 shadow-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative w-10 h-7 rounded-lg overflow-hidden shrink-0 border border-slate-200 bg-slate-900">
              <Image
                src="/images/vulcan/display.jpg"
                alt="Vulcan Anti Cheat"
                fill
                className="object-cover"
              />
            </div>
            <div className="min-w-0">
              <span className="font-semibold text-xs text-[#002D47] block truncate">
                Vulcan Anti Cheat
              </span>
              <span className="text-[10px] text-slate-500 block">
                Packet Level Anti Cheat
              </span>
            </div>
          </div>
          <span className="text-xs font-bold text-slate-700 shrink-0">
            Rp 15.000
          </span>
        </div>
      </div>

      {/* BuiltByBit Reference 2: Price Calculation Breakdown */}
      <div className="mt-3.5 pt-3 border-t border-amber-200/60 text-xs space-y-1.5">
        <div className="flex items-center justify-between text-slate-500">
          <span>Original price:</span>
          <span className="line-through font-medium text-red-500">Rp 40.000</span>
        </div>
        <div className="flex items-center justify-between text-emerald-700 font-semibold">
          <span>Bundle discount:</span>
          <span>25% off (-Rp 10.000)</span>
        </div>
        <div className="flex items-center justify-between pt-1.5 border-t border-dashed border-slate-200">
          <span className="font-bold text-[#002D47] text-sm">Subtotal:</span>
          <span className="font-minecraft text-xl font-bold text-emerald-600">
            Rp 30.000
          </span>
        </div>
      </div>

      {/* CTA Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="mc-btn-primary w-full text-white font-minecraft text-xs font-bold py-3 rounded-xl flex items-center justify-center gap-2 shadow-md cursor-pointer mt-4 hover:scale-105 active:scale-95 transition-all text-center"
      >
        <ShoppingBag className="w-4 h-4" />
        <span>Beli Bundle (Rp 30.000)</span>
      </a>

      {/* Small Guarantee / Advantage Note */}
      <div className="mt-2.5 text-[10px] text-slate-500 text-center flex items-center justify-center gap-1.5">
        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
        <span>Dapat 2 Plugin Lengkap • Hemat Rp 10.000 Langsung</span>
      </div>
    </div>
  );
}
