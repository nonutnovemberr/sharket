'use client';

import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import Image from 'next/image';
import { ChevronLeft, ChevronRight, Maximize2, X } from 'lucide-react';

interface MediaGalleryProps {
  pluginName: string;
}

export default function PluginMediaGallery({ pluginName }: MediaGalleryProps) {
  const isAuction = pluginName.toLowerCase().includes('auction');
  const isCrates = pluginName.toLowerCase().includes('crate');
  const isVulcan = pluginName.toLowerCase().includes('vulcan');

  const screenshots = isAuction
    ? [
        { id: 1, src: '/images/sharket-auctions/banner-official.jpg', title: 'Official SharketAuctions Banner Logo' },
        { id: 2, src: '/images/sharket-auctions/browse-gui.jpg', title: 'Main Auction House GUI & Collect' },
        { id: 3, src: '/images/sharket-auctions/filter-gui.jpg', title: 'Category Filter (Blocks, Tools, Combat, Food...)' },
        { id: 4, src: '/images/sharket-auctions/listings-gui.jpg', title: 'Your Active Listings & Item Management' },
        { id: 5, src: '/images/sharket-auctions/history-gui.jpg', title: 'Transaction History & Financial Summary' },
        { id: 6, src: '/images/sharket-auctions/sign-search.jpg', title: 'Interactive Sign GUI Item Search' },
        { id: 7, src: '/images/sharket-auctions/commands.jpg', title: 'Command Auto-Completion (/ah)' },
        { id: 8, src: '/images/sharket-auctions/alerts.png', title: 'Auction Broadcast Alert Notifications' },
        { id: 9, src: '/images/sharket-auctions/spark-profile.png', title: 'Spark Profiler: 0.00% Server Thread Performance' },
      ]
    : isCrates
    ? [
        { id: 1, src: '/images/sharket-crates/banner-official.jpg', title: 'Official SharketCrates Banner Logo' },
        { id: 2, src: '/images/sharket-crates/crates-world-lineup.jpg', title: 'In-World Holograms & Crate Lineup (/store & Keys)' },
        { id: 3, src: '/images/sharket-crates/crate-editor-gui.jpg', title: 'In-Game Crate Manager GUI (/sc gui)' },
        { id: 4, src: '/images/sharket-crates/amethyst-editor-gui.jpg', title: 'Amethyst Crate Rewards & In-Game GUI Configuration' },
        { id: 5, src: '/images/sharket-crates/commands-hologram.jpg', title: 'Real-Time Hologram Keys & Command Auto-Completion (/sc)' },
        { id: 6, src: '/images/sharket-crates/crimson-crate-gui.jpg', title: 'Crimson Crate - Choose 1 of 7 Custom Armor & Weapons' },
        { id: 7, src: '/images/sharket-crates/gold-crate-gui.jpg', title: 'Gold Crate - Spawner Rewards Selection' },
        { id: 8, src: '/images/sharket-crates/prime-crate-gui.jpg', title: 'Prime Crate - Elite Netherite Gear & Pickaxe' },
        { id: 9, src: '/images/sharket-crates/spark-profile.png', title: 'Spark Profiler: 0.01% Server Thread Performance' },
      ]
    : isVulcan
    ? [
        { id: 1, src: '/images/vulcan/display.jpg', title: 'Official Vulcan Anti Cheat Banner' },
        { id: 2, src: '/images/vulcan/chat-alerts.png', title: 'In-Game Staff Alerts & VL Tracking' },
        { id: 3, src: '/images/vulcan/connection-info.png', title: 'Connection Profiler & Network Ping Analysis (/vulcan connection)' },
        { id: 4, src: '/images/vulcan/judgement-day.png', title: 'Vulcan Judgement Day Automated Ban Wave (/jday)' },
        { id: 5, src: '/images/vulcan/config-alerts.jpg', title: 'Alerts Format & Placeholder Configuration' },
        { id: 6, src: '/images/vulcan/discord-punishment.png', title: 'Discord Webhook Live Punishment Notification' },
        { id: 7, src: '/images/vulcan/discord-alerts.png', title: 'Discord Webhook Real-Time Alert Embed' },
      ]
    : [
        { id: 1, src: '/images/sussy-baka/banner-official.jpg', title: 'Official SussyBaka Banner Logo' },
        { id: 2, src: '/images/sussy-baka/anticheat-supported.jpg', title: 'Supported Anti Cheats Integration' },
        { id: 3, src: '/images/sussy-baka/sort-gui.jpg', title: 'GUI Sort Mode (Most Flagged / Recently Flagged)' },
        { id: 4, src: '/images/sussy-baka/refresh-gui.jpg', title: 'GUI Quick Refresh & Player Investigation' },
        { id: 5, src: '/images/sussy-baka/config.jpg', title: 'Config & Teleport Settings (/sussybaka)' },
        { id: 6, src: '/images/sussy-baka/spark-profile.png', title: 'Spark Profiler: 0.01% Server Thread Performance' },
      ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const thumbnailsRef = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    setMounted(true);
  }, []);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? screenshots.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev === screenshots.length - 1 ? 0 : prev + 1));
  };

  // Keyboard navigation & lock body scroll when lightbox is open
  useEffect(() => {
    if (!lightboxOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightboxOpen(false);
      } else if (e.key === 'ArrowLeft') {
        setCurrentIndex((prev) => (prev === 0 ? screenshots.length - 1 : prev - 1));
      } else if (e.key === 'ArrowRight') {
        setCurrentIndex((prev) => (prev === screenshots.length - 1 ? 0 : prev + 1));
      }
    };

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [lightboxOpen, screenshots.length]);

  // Auto-scroll thumbnail strip to center the active thumbnail when slide changes
  useEffect(() => {
    const activeThumb = thumbnailsRef.current[currentIndex];
    if (activeThumb) {
      activeThumb.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center',
      });
    }
  }, [currentIndex]);

  return (
    <div className="w-full mb-8 select-none">
      {/* Main Viewport Container */}
      <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] max-h-[460px] rounded-2xl overflow-hidden bg-[#111722] border-2 border-sky-950/40 shadow-xl group">
        
        {/* Current Active Image (Click to Open Lightbox) */}
        <div 
          onClick={() => setLightboxOpen(true)}
          className="relative w-full h-full flex items-center justify-center p-2 sm:p-4 cursor-zoom-in"
          title="Klik untuk melihat ukuran penuh"
        >
          <Image
            src={screenshots[currentIndex].src}
            alt={`${pluginName} - ${screenshots[currentIndex].title}`}
            fill
            priority
            className="object-contain object-center transition-all duration-300"
          />
        </div>

        {/* Top-Right Fullscreen Zoom Button */}
        <button
          onClick={() => setLightboxOpen(true)}
          className="absolute top-3 right-3 p-2 rounded-xl bg-black/60 hover:bg-black/80 text-white/80 hover:text-white backdrop-blur-md border border-white/10 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer shadow-md"
          title="Lihat ukuran penuh"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        {/* Slide Counter Badge */}
        <div className="absolute top-3 left-3 px-3 py-1 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 text-white text-xs font-mono font-medium">
          {currentIndex + 1} / {screenshots.length}
        </div>

        {/* Big Overlay Navigation Chevrons on Main Image */}
        <button
          onClick={prevSlide}
          className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-md border border-white/15 transition-all opacity-80 sm:opacity-0 group-hover:opacity-100 hover:scale-110 active:scale-95 cursor-pointer shadow-lg"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <button
          onClick={nextSlide}
          className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-md border border-white/15 transition-all opacity-80 sm:opacity-0 group-hover:opacity-100 hover:scale-110 active:scale-95 cursor-pointer shadow-lg"
          aria-label="Next slide"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* BuiltByBit-Style Thumbnail Strip Carousel */}
      <div className="mt-3.5 flex items-center justify-between gap-2.5 sm:gap-3 bg-[#0d141e]/90 p-2 sm:p-2.5 rounded-2xl border border-sky-900/40 shadow-inner">
        
        {/* Left Arrow Button */}
        <button
          onClick={prevSlide}
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-slate-800/90 hover:bg-sky-600 text-white flex items-center justify-center shrink-0 border border-white/10 hover:border-sky-300 transition-all cursor-pointer hover:scale-105 active:scale-95 shadow-sm"
          aria-label="Previous thumbnail"
        >
          <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Thumbnail Items Container with Auto-Scroll on Slide Change */}
        <div className="flex-1 flex items-center gap-1.5 sm:gap-2.5 overflow-x-auto py-1.5 scroll-smooth scrollbar-none px-1">
          {screenshots.map((item, idx) => {
            const isActive = idx === currentIndex;
            return (
              <button
                key={item.id}
                ref={(el) => {
                  thumbnailsRef.current[idx] = el;
                }}
                onClick={() => setCurrentIndex(idx)}
                className={`relative w-14 h-9 sm:w-20 sm:h-13 rounded-lg overflow-hidden shrink-0 cursor-pointer transition-all duration-200 border-2 ${
                  isActive
                    ? 'border-sky-400 ring-2 ring-sky-400/50 scale-105 opacity-100 shadow-md bg-slate-900'
                    : 'border-slate-800 opacity-45 hover:opacity-90 hover:border-slate-600 bg-slate-950'
                }`}
                title={item.title}
              >
                <Image
                  src={item.src}
                  alt={item.title}
                  fill
                  className="object-cover object-center"
                />
              </button>
            );
          })}
        </div>

        {/* Right Arrow Button */}
        <button
          onClick={nextSlide}
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-slate-800/90 hover:bg-sky-600 text-white flex items-center justify-center shrink-0 border border-white/10 hover:border-sky-300 transition-all cursor-pointer hover:scale-105 active:scale-95 shadow-sm"
          aria-label="Next thumbnail"
        >
          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

      </div>

      {/* Lightbox Modal (Full-Screen Viewport Preview rendered into document.body via Portal) */}
      {mounted && lightboxOpen && createPortal(
        <div 
          onClick={() => setLightboxOpen(false)}
          className="fixed inset-0 z-[999999] bg-black/95 backdrop-blur-xl flex flex-col justify-between p-3 sm:p-6 animate-in fade-in duration-200 select-none"
        >
          {/* Top Bar: Title & Close Button */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-7xl mx-auto flex items-center justify-between gap-4 py-2 px-3 bg-slate-900/80 rounded-2xl border border-white/10 backdrop-blur-md shrink-0 shadow-lg"
          >
            <div className="flex items-center gap-3 overflow-hidden">
              <span className="px-2.5 py-1 rounded-lg bg-sky-500/20 text-sky-300 font-mono text-xs font-semibold shrink-0 border border-sky-400/30">
                {currentIndex + 1} / {screenshots.length}
              </span>
              <p className="text-white text-xs sm:text-sm font-medium truncate">
                {screenshots[currentIndex].title}
              </p>
            </div>

            <button
              onClick={() => setLightboxOpen(false)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-red-500/80 text-white text-xs font-medium cursor-pointer transition-all border border-white/10 hover:border-red-400 shrink-0"
              title="Tutup (Esc)"
            >
              <span className="hidden sm:inline">Tutup</span>
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Central Image Viewport with Large Navigation Arrows */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-7xl h-[68vh] sm:h-[76vh] mx-auto my-auto flex items-center justify-center"
          >
            <div className="relative w-full h-full rounded-2xl overflow-hidden flex items-center justify-center p-2 sm:p-4">
              <Image
                src={screenshots[currentIndex].src}
                alt={screenshots[currentIndex].title}
                fill
                priority
                className="object-contain"
              />
            </div>
            
            {/* Previous Button */}
            <button
              onClick={prevSlide}
              className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-900/80 hover:bg-sky-600 text-white flex items-center justify-center cursor-pointer border border-white/20 hover:border-sky-300 transition-all shadow-2xl hover:scale-110 active:scale-95"
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-7 h-7 sm:w-8 sm:h-8" />
            </button>

            {/* Next Button */}
            <button
              onClick={nextSlide}
              className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-900/80 hover:bg-sky-600 text-white flex items-center justify-center cursor-pointer border border-white/20 hover:border-sky-300 transition-all shadow-2xl hover:scale-110 active:scale-95"
              aria-label="Next slide"
            >
              <ChevronRight className="w-7 h-7 sm:w-8 sm:h-8" />
            </button>
          </div>

          {/* Bottom Thumbnail Strip for Fast Navigation in Fullscreen */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-4xl mx-auto flex items-center justify-center gap-2 overflow-x-auto py-2 px-3 bg-slate-900/60 rounded-2xl border border-white/10 backdrop-blur-md shrink-0 scrollbar-none"
          >
            {screenshots.map((item, idx) => {
              const isActive = idx === currentIndex;
              return (
                <button
                  key={`lb-${item.id}`}
                  onClick={() => setCurrentIndex(idx)}
                  className={`relative w-12 h-8 sm:w-16 sm:h-10 rounded-lg overflow-hidden shrink-0 cursor-pointer transition-all duration-150 border-2 ${
                    isActive
                      ? 'border-sky-400 ring-2 ring-sky-400/50 scale-105 opacity-100 shadow-md bg-slate-900'
                      : 'border-slate-700 opacity-40 hover:opacity-85 hover:border-slate-500 bg-slate-950'
                  }`}
                  title={item.title}
                >
                  <Image
                    src={item.src}
                    alt={item.title}
                    fill
                    className="object-cover object-center"
                  />
                </button>
              );
            })}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
