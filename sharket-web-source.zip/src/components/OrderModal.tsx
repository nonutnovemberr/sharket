'use client';

import React, { useState, useEffect } from 'react';
import { X, Send, ShieldCheck } from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPluginId?: string;
}

export default function OrderModal({ isOpen, onClose, defaultPluginId }: OrderModalProps) {
  const [selectedProduct, setSelectedProduct] = useState(defaultPluginId || 'sharket-auctions');
  const [adminPhone, setAdminPhone] = useState('628134784046');

  useEffect(() => {
    if (defaultPluginId) {
      setSelectedProduct(defaultPluginId);
    }
  }, [defaultPluginId]);

  if (!isOpen) return null;

  let pluginName = 'SharketAuctions';

  if (selectedProduct === 'sharket-auctions') {
    pluginName = 'SharketAuctions';
  } else if (selectedProduct === 'sharket-crates') {
    pluginName = 'SharketCrates';
  } else if (selectedProduct === 'sussy-baka') {
    pluginName = 'SussyBaka';
  } else if (selectedProduct === 'vulcan') {
    pluginName = 'Vulcan Anti Cheat';
  } else if (selectedProduct === 'bundle-security') {
    pluginName = 'Bundle SussyBaka + Vulcan Anti Cheat';
  }

  // Exact simple WhatsApp message requested by user
  const messageText = selectedProduct === 'bundle-security'
    ? 'halo\nsaya ingin membeli paket bundle "SussyBaka + Vulcan Anti Cheat" (Rp 30.000)'
    : `halo\nsaya ingin membeli plugin "${pluginName}"`;

  const handleSendWhatsApp = () => {
    const encoded = encodeURIComponent(messageText);
    const waUrl = `https://wa.me/${adminPhone}?text=${encoded}`;
    window.open(waUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full border-2 border-sky-300 shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#608B9E] via-[#749EB1] to-[#86B0C0] text-white p-5 flex items-center justify-between shrink-0">
          <div>
            <h3 className="font-minecraft text-lg sm:text-xl font-bold tracking-wide">
              ORDER SHARKET PLUGIN
            </h3>
            <p className="text-xs text-sky-100">
              Pemesanan Langsung via WhatsApp
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-5">
          
          {/* Select Product */}
          <div>
            <label className="block text-xs font-bold text-[#002D47] uppercase tracking-wider mb-2">
              Pilih Plugin:
            </label>
            <div className="grid grid-cols-1 gap-2.5">
              <label className={`flex items-center justify-between p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedProduct === 'sharket-auctions' ? 'border-[#38BDF8] bg-sky-50/80 shadow-xs' : 'border-sky-100 bg-white hover:bg-sky-50'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="product"
                    value="sharket-auctions"
                    checked={selectedProduct === 'sharket-auctions'}
                    onChange={() => setSelectedProduct('sharket-auctions')}
                    className="accent-[#00BDF6] w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <span className="font-minecraft text-xs sm:text-sm font-bold text-[#002D47] block">
                      SharketAuctions
                    </span>
                    <span className="text-[11px] text-slate-500">Auction House + Shulker Preview</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-red-500 line-through block font-medium">Rp 60.000</span>
                  <span className="font-minecraft text-xs font-bold text-emerald-600">Rp 39.999</span>
                </div>
              </label>

              <label className={`flex items-center justify-between p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedProduct === 'sharket-crates' ? 'border-[#2DD4BF] bg-teal-50/80 shadow-xs' : 'border-sky-100 bg-white hover:bg-sky-50'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="product"
                    value="sharket-crates"
                    checked={selectedProduct === 'sharket-crates'}
                    onChange={() => setSelectedProduct('sharket-crates')}
                    className="accent-[#2DD4BF] w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <span className="font-minecraft text-xs sm:text-sm font-bold text-[#002D47] block">
                      SharketCrates
                    </span>
                    <span className="text-[11px] text-slate-500">DonutSMP Style Crate & KeyAll System</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-red-500 line-through block font-medium">Rp 25.000</span>
                  <span className="font-minecraft text-xs font-bold text-emerald-600">Rp 15.000</span>
                </div>
              </label>

              <label className={`flex items-center justify-between p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedProduct === 'sussy-baka' ? 'border-amber-400 bg-amber-50/70 shadow-xs' : 'border-sky-100 bg-white hover:bg-sky-50'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="product"
                    value="sussy-baka"
                    checked={selectedProduct === 'sussy-baka'}
                    onChange={() => setSelectedProduct('sussy-baka')}
                    className="accent-amber-500 w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <span className="font-minecraft text-xs sm:text-sm font-bold text-[#002D47] block">
                      SussyBaka
                    </span>
                    <span className="text-[11px] text-slate-500">Player Surveillance & Security Audit</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-red-500 line-through block font-medium">Rp 40.000</span>
                  <span className="font-minecraft text-xs font-bold text-emerald-600">Rp 24.999</span>
                </div>
              </label>

              <label className={`flex items-center justify-between p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedProduct === 'vulcan' ? 'border-orange-500 bg-orange-50/70 shadow-xs' : 'border-sky-100 bg-white hover:bg-sky-50'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="product"
                    value="vulcan"
                    checked={selectedProduct === 'vulcan'}
                    onChange={() => setSelectedProduct('vulcan')}
                    className="accent-orange-500 w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <span className="font-minecraft text-xs sm:text-sm font-bold text-[#002D47] block">
                      Vulcan Anti Cheat
                    </span>
                    <span className="text-[11px] text-slate-500">Advanced Packet Level Anti Cheat (Tanpa Lisensi)</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-red-500 line-through block font-medium">Rp 25.000</span>
                  <span className="font-minecraft text-xs font-bold text-emerald-600">Rp 15.000</span>
                </div>
              </label>

              <label className={`flex items-center justify-between p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedProduct === 'bundle-security' ? 'border-red-500 bg-red-50/70 shadow-xs' : 'border-amber-200 bg-amber-50/30 hover:bg-amber-50'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="product"
                    value="bundle-security"
                    checked={selectedProduct === 'bundle-security'}
                    onChange={() => setSelectedProduct('bundle-security')}
                    className="accent-red-500 w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-minecraft text-xs sm:text-sm font-bold text-[#002D47] block">
                        Bundle SussyBaka + Vulcan
                      </span>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-600 text-white leading-none">
                        25% OFF
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500">Paket Hemat Moderasi & Anti Cheat</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-red-500 line-through block font-medium">Rp 40.000</span>
                  <span className="font-minecraft text-xs font-bold text-emerald-600">Rp 30.000</span>
                </div>
              </label>
            </div>
          </div>

          {/* WhatsApp Message Preview */}
          <div>
            <span className="text-xs font-bold text-[#002D47] uppercase tracking-wider mb-1.5 block">
              Pratinjau Pesan WhatsApp:
            </span>
            <div className="bg-sky-50/90 border border-sky-200 rounded-2xl p-4 text-xs sm:text-sm text-sky-950 font-mono-code whitespace-pre-line shadow-inner">
              {messageText}
            </div>
          </div>

          {/* Note Info Requested by User */}
          <div className="flex items-center gap-2.5 text-xs text-sky-900 bg-sky-100/70 p-3.5 rounded-2xl border border-sky-200">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="leading-relaxed font-medium">
              Admin akan langsung mengirim berkas file .jar dan License Key aktivasi Anda setelah pembayaran
            </span>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
          >
            Batal
          </button>
          <button
            onClick={handleSendWhatsApp}
            className="mc-btn-primary px-6 py-3 rounded-xl text-white font-minecraft text-xs sm:text-sm font-bold flex items-center gap-2 shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>KIRIM KE WHATSAPP</span>
          </button>
        </div>

      </div>
    </div>
  );
}
