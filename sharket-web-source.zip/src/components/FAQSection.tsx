'use client';

import React, { useState } from 'react';
import { FAQS } from '@/data/plugins';
import { ChevronDown, HelpCircle, MessageSquare } from 'lucide-react';

interface FAQSectionProps {
  onOpenOrder?: () => void;
}

export default function FAQSection({ onOpenOrder }: FAQSectionProps) {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-16 sm:py-20 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-minecraft font-bold bg-sky-100 text-sky-800 border border-sky-200 mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-sky-600" />
            FREQUENTLY ASKED QUESTIONS
          </div>
          <h2 className="font-minecraft text-2xl sm:text-4xl font-bold text-[#002D47] tracking-tight">
            PERTANYAAN UMUM
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600">
            Hal yang sering ditanyakan mengenai instalasi, lisensi, dan dukungan server.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-3.5">
          {FAQS.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="bg-white/95 backdrop-blur-sm rounded-2xl border border-sky-200 overflow-hidden shadow-sm transition-all hover:border-sky-300"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 font-semibold text-sm sm:text-base text-[#002D47] hover:text-sky-600 transition-colors cursor-pointer"
                >
                  <span className="font-bold flex items-center gap-3">
                    <span className="font-minecraft text-xs text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded border border-sky-200">
                      Q{idx + 1}
                    </span>
                    {faq.q}
                  </span>
                  <ChevronDown className={`w-5 h-5 text-sky-500 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180 text-sky-700' : ''
                  }`} />
                </button>

                {isOpen && (
                  <div className="px-5 pb-6 sm:px-6 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-sky-100 bg-sky-50/40">
                    {faq.a.includes('channel WhatsApp') ? (
                      <>
                        {faq.a.split('channel WhatsApp')[0]}
                        <a
                          href="https://whatsapp.com/channel/0029Vb9CNokBFLgS3bTmwd3P"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-700 underline font-semibold transition-colors"
                        >
                          channel WhatsApp
                        </a>
                        {faq.a.split('channel WhatsApp')[1]}
                      </>
                    ) : (
                      faq.a
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions banner */}
        <div className="mt-12 text-center p-6 sm:p-8 bg-gradient-to-r from-[#0092d6] via-[#00BDF6] to-[#38bdf8] rounded-3xl text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4 border border-sky-200">
          <div className="text-left">
            <h4 className="font-minecraft text-lg sm:text-xl font-bold">
              Masih Ada Pertanyaan Lain?
            </h4>
            <p className="text-xs sm:text-sm text-sky-100 mt-1">
              Hubungi langsung admin kami via WhatsApp atau Discord. Kami siap membantu setup server Anda!
            </p>
          </div>
          <a
            href={`https://wa.me/628134784046?text=${encodeURIComponent('halo\nsaya ingin bertanya ...')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mc-btn-yellow px-6 py-3 rounded-xl font-minecraft text-xs sm:text-sm font-bold text-[#002D47] shrink-0 shadow-lg cursor-pointer hover:scale-105 active:scale-95 transition-all text-center"
          >
            Tanya Admin di WA
          </a>
        </div>

      </div>
    </section>
  );
}
