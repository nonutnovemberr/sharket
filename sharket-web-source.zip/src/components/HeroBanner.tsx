'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';
import InteractiveBubbles from './InteractiveBubbles';

export default function HeroBanner() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const word1 = 'SHARKET'.split('');
  const word2 = 'PLUGIN'.split('');

  // Letter pop-out intensity based on proximity to hovered letter
  const getLetterStyle = (index: number) => {
    if (hoveredIndex === null) {
      return 'transform translate-y-0 scale-100';
    }
    const dist = Math.abs(hoveredIndex - index);
    if (dist === 0) {
      return 'transform -translate-y-3.5 scale-135 z-20 brightness-130 text-white drop-shadow-[0_0_20px_rgba(186,230,253,1)]';
    } else if (dist === 1) {
      return 'transform -translate-y-1.5 scale-115 z-10 brightness-110 drop-shadow-[0_0_10px_rgba(186,230,253,0.7)]';
    }
    return 'transform translate-y-0 scale-100 opacity-90';
  };

  return (
    <section id="hero" className="relative overflow-hidden pt-6 pb-24 bg-gradient-to-b from-[#608B9E] via-[#749EB1] to-[#86B0C0] text-white">
      
      {/* Ambient Sunrays Caustics from ocean surface */}
      <div className="absolute inset-0 ocean-sunrays pointer-events-none opacity-20 z-0" />

      {/* Interactive Clickable & Poppable Ocean Bubbles */}
      <InteractiveBubbles />

      {/* Floating Minecraft Ambient Pixel Particles */}
      <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
        <div className="absolute top-16 left-[10%] w-3 h-3 bg-white/30 rounded-xs rotate-12 animate-pulse" />
        <div className="absolute top-32 left-[22%] w-2 h-2 bg-sky-200/40 rounded-xs -rotate-12 animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-24 right-[12%] w-3.5 h-3.5 bg-sky-100/25 rounded-xs -rotate-6 animate-pulse" style={{ animationDelay: '1.5s' }} />
        <div className="absolute top-44 right-[24%] w-2.5 h-2.5 bg-white/20 rounded-xs rotate-45 animate-pulse" style={{ animationDelay: '2.2s' }} />
        <div className="absolute bottom-28 left-[15%] w-3 h-3 bg-white/25 rounded-xs rotate-45 animate-pulse" style={{ animationDelay: '2.5s' }} />
        <div className="absolute bottom-36 right-[18%] w-3 h-3 bg-amber-200/30 rounded-xs rotate-12 animate-pulse" style={{ animationDelay: '1.8s' }} />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20 flex flex-col items-center">
        
        {/* Seamless Shark Banner (Zero harsh borders, perfectly matches #86B0C0 ocean) */}
        <div className="relative w-full max-w-4xl rounded-3xl overflow-hidden bg-[#86B0C0] transition-all duration-300">
          
          <div className="relative w-full h-[320px] sm:h-[380px] md:h-[440px]">
            <Image
              src="/images/shark-banner.jpg"
              alt="Sharket Plugin Minecraft Shark"
              fill
              priority
              className="object-cover object-center filter brightness-95"
            />

            {/* Seamless Soft Edge Feathering to merge smoothly into background */}
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#86B0C0]/10 to-[#86B0C0]/40 pointer-events-none" />

            {/* Centered Interactive Pastel Title */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4 z-10 pointer-events-auto">
              
              <div 
                onMouseLeave={() => setHoveredIndex(null)}
                className="select-none py-3 px-5 inline-flex flex-wrap items-center justify-center gap-x-4 cursor-pointer"
              >
                {/* Word 1: SHARKET in Soft Pastel Cyan */}
                <div className="inline-flex">
                  {word1.map((char, idx) => (
                    <span
                      key={idx}
                      onMouseEnter={() => setHoveredIndex(idx)}
                      className={`font-minecraft-title text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-wider inline-block text-[#BAE6FD] mc-shadow-pastel-cyan transition-all duration-200 ${getLetterStyle(idx)}`}
                    >
                      {char}
                    </span>
                  ))}
                </div>

                {/* Word 2: PLUGIN in Soft Pastel Light Yellow (#FEF08A) */}
                <div className="inline-flex">
                  {word2.map((char, idx) => {
                    const globalIdx = word1.length + idx;
                    return (
                      <span
                        key={idx}
                        onMouseEnter={() => setHoveredIndex(globalIdx)}
                        className={`font-minecraft-title text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-wider inline-block text-[#FEF08A] mc-shadow-pastel-yellow transition-all duration-200 ${getLetterStyle(globalIdx)}`}
                      >
                        {char}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Subtle Pastel Badge */}
              <div className="mt-2">
                <span className="text-[11px] font-minecraft text-sky-100 tracking-wide bg-[#2a5062]/80 px-4 py-1 rounded-full backdrop-blur-md border border-sky-200/40 shadow-sm">
                  High Performance Minecraft Plugins
                </span>
              </div>

            </div>

          </div>
        </div>

        {/* Tombol Di Bawah Banner Yang Menavigasi ke Halaman Plugin */}
        <div className="mt-8 flex justify-center w-full relative z-20">
          <Link
            href="/plugins"
            className="mc-btn-yellow group text-[#002D47] font-minecraft text-xs sm:text-sm font-bold px-8 py-4 rounded-2xl shadow-xl flex items-center gap-3 hover:scale-105 active:scale-95 transition-all cursor-pointer border-2 border-amber-300"
          >
            <Sparkles className="w-4 h-4 text-amber-700" />
            <span>LIHAT SEMUA PLUGIN</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform" />
          </Link>
        </div>

      </div>

      {/* Crisp Curved Wave SVG Bottom Transition (High contrast separation like Calmionix) */}
      <div className="absolute -bottom-1 left-0 right-0 w-full overflow-hidden leading-none pointer-events-none z-10">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="relative block w-full h-14 sm:h-20 md:h-24 drop-shadow-[0_-4px_6px_rgba(0,0,0,0.04)]"
          preserveAspectRatio="none"
        >
          <path
            d="M0,36 C320,105 600,0 900,52 C1160,98 1320,16 1440,36 L1440,120 L0,120 Z"
            fill="#DEF3FC"
          />
        </svg>
      </div>

    </section>
  );
}
