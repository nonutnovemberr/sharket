'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { PluginItem } from '@/data/plugins';
import { ShoppingBag, ArrowUpRight } from 'lucide-react';

interface ProductCardProps {
  plugin: PluginItem;
}

export default function ProductCard({ plugin }: ProductCardProps) {
  const isAuction = plugin.id === 'sharket-auctions';

  return (
    <Link
      href={`/products/${plugin.id}`}
      className="card-glass rounded-2xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:border-sky-400 group cursor-pointer block shadow-sm hover:shadow-lg bg-white/95"
    >
      <div>
        {/* Modrinth & BuiltByBit Style Top Banner Image */}
        <div className="relative w-full aspect-[16/9] sm:aspect-[1024/553] overflow-hidden bg-slate-900">
          <Image
            src={plugin.id === 'vulcan' ? '/images/vulcan/display.jpg' : `/images/${plugin.id}/banner-official.jpg`}
            alt={plugin.name}
            fill
            className="object-cover object-center group-hover:scale-105 transition-transform duration-300"
          />

          {/* BuiltByBit-style Price Tag Overlaid at Bottom Right of Banner */}
          <div className="absolute bottom-3 right-3 bg-black/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/20 text-right shadow-md">
            <span className="text-[10px] text-red-400 line-through block leading-none font-medium">
              {plugin.originalPrice}
            </span>
            <span className="font-minecraft text-sm sm:text-base font-bold text-emerald-400 block mt-0.5">
              {plugin.price}
            </span>
          </div>

          {/* Modrinth Tag Pill Top Left */}
          <div className="absolute top-3 left-3">
            <span className="bg-black/60 backdrop-blur-md text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-lg text-sky-200 border border-white/15">
              {plugin.category}
            </span>
          </div>
        </div>

        {/* Card Body (Modrinth & BuiltByBit Layout) */}
        <div className="p-5 sm:p-6">
          
          {/* Title */}
          <div className="flex items-start justify-between gap-2">
            <div>
              <h2 className="font-minecraft text-lg sm:text-xl font-bold text-[#002D47] group-hover:text-sky-600 transition-colors">
                {plugin.name}
              </h2>
            </div>

            <div className="w-8 h-8 rounded-lg bg-sky-50 flex items-center justify-center text-slate-400 group-hover:text-sky-600 group-hover:bg-sky-100 transition-colors shrink-0">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-3 line-clamp-2">
            {plugin.description}
          </p>

        </div>
      </div>

      {/* Card Footer: Purchases Stats Bar (Modrinth / BuiltByBit Style) */}
      <div className="px-5 sm:px-6 py-3.5 bg-slate-50/80 border-t border-sky-100 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-1.5 font-medium text-slate-600">
          <ShoppingBag className="w-3.5 h-3.5 text-slate-400" />
          <span>{plugin.salesCount} purchased</span>
        </div>

        <span className="text-[11px] text-sky-600 font-semibold group-hover:underline">
          View Resource &rarr;
        </span>
      </div>

    </Link>
  );
}
